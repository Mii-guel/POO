package com.mycompany.safesystem; 

import java.util.ArrayList; 
import java.util.Collection; 
import java.util.concurrent.locks.Lock; 
import java.util.concurrent.locks.ReentrantLock; 

public class PrimesList extends ArrayList<Integer> {

    
    private final Lock lock = new ReentrantLock();

    
    public boolean isPrime(int number) {
        if (number <= 1) {
            return false; // Los números menores o iguales a 1 no son primos
        }
        // Solo necesitamos verificar hasta la raíz cuadrada del número
        for (int i = 2; i * i <= number; i++) {
            if (number % i == 0) {
                return false; // Si es divisible por algún número, no es primo
            }
        }
        return true; // Si no encontró divisores, es primo
    }

    
    @Override
    public synchronized boolean add(Integer element) { 
        if (element == null) {
            throw new IllegalArgumentException("No se puede añadir un valor nulo a la lista de primos.");
        }
        if (!isPrime(element)) {
            throw new IllegalArgumentException("Solo se pueden añadir números primos. '" + element + "' no es primo.");
        }
        return super.add(element); // Llama al método add original de ArrayList
    }

    
    @Override
    public boolean addAll(Collection<? extends Integer> c) {
        lock.lock(); // Adquiere el bloqueo antes de modificar la lista
        try {
            for (Integer element : c) {
                if (element == null || !isPrime(element)) {
                    throw new IllegalArgumentException("La colección contiene elementos no primos o nulos. '" + element + "' no es primo.");
                }
            }
            return super.addAll(c); // Llama al método addAll original de ArrayList
        } finally {
            lock.unlock(); // Libera el bloqueo en cualquier caso
        }
    }

    
    @Override
    public synchronized boolean remove(Object o) { 
        
        return super.remove(o); // Llama al método remove original de ArrayList
    }

    
    public int getPrimesCount() {
        lock.lock(); // Adquiere el bloqueo para una lectura consistente
        try {
            return this.size(); // Retorna el tamaño de la lista
        } finally {
            lock.unlock(); // Libera el bloqueo
        }
    }

    
    public synchronized void waitForPrimes() throws InterruptedException {
        while (isEmpty()) { // Espera mientras la lista esté vacía
            System.out.println("Lista de primos vacía, esperando...");
            wait(); // Libera el bloqueo y espera a ser notificado
        }
    }

    
    public synchronized void notifyPrimesAvailable() {
        notifyAll(); // Notifica a todos los hilos esperando en este objeto
    }
}
