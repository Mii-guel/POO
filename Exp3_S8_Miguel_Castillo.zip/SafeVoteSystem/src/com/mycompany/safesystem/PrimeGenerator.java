package com.mycompany.safesystem; 

import java.io.*; 
import java.util.ArrayList; 
import java.util.List; 
import java.util.Random; 
import java.util.concurrent.ExecutorService; 
import java.util.concurrent.Executors; 
import java.util.concurrent.TimeUnit; 

public class PrimeGenerator {

    // Rutas de los archivos
    private static final String PRIMES_CSV_FILE = "primes.csv";
    private static final String ENCRYPTED_MESSAGES_FILE = "encrypted_messages.txt";

    public static void main(String[] args) {
        System.out.println("--- Iniciando SafeVoteSystem ---");

        // Crear instancias de PrimesList y MessageQueue
        PrimesList primesList = new PrimesList();
        MessageQueue messageQueue = new MessageQueue();

        // Cargar números primos iniciales desde CSV
        cargarPrimesDesdeCSV(primesList, PRIMES_CSV_FILE);

        // Configuración de hilos para generar más primos
        ExecutorService executor = Executors.newFixedThreadPool(3); // Pool de 3 hilos

        // Crear y enviar tareas (PrimesThread) al pool de hilos
        for (int i = 0; i < 3; i++) {
            // Cada hilo intentará generar 50 números aleatorios
            Runnable worker = new PrimesThread(primesList, 50, "Generador-" + (i + 1));
            executor.execute(worker); // Inicia el hilo
        }

        // Este hilo principal esperará a que haya primos disponibles y los usará.
        Thread messageProcessorThread = new Thread(() -> {
            Random rand = new Random();
            for (int i = 0; i < 10; i++) { // Intentará procesar 10 mensajes
                try {
                    primesList.waitForPrimes(); // Espera a que haya primos disponibles
                    
                    Integer prime = null;
                    synchronized (primesList) { 
                        if (!primesList.isEmpty()) {
                            prime = primesList.remove(0); // Obtiene un primo para usarlo en encriptación
                            System.out.println("Procesador de mensajes: Usando primo " + prime + " para mensaje.");
                        }
                    }

                    if (prime != null) {
                        String encryptedMessage = "MensajeEncriptado_" + (i + 1) + "_con_Primo_" + prime;
                        messageQueue.publishToTopic("VotosSeguros", encryptedMessage); // Publica al Topic
                        
                        Thread.sleep(rand.nextInt(100) + 50); // Pausa entre 50 y 150ms
                    }
                } catch (InterruptedException e) {
                    System.err.println("Procesador de mensajes interrumpido.");
                    Thread.currentThread().interrupt();
                    break;
                } catch (Exception e) {
                    System.err.println("Error en procesador de mensajes: " + e.getMessage());
                }
            }
            System.out.println("Procesador de mensajes ha terminado.");
        }, "MessageProcessor");

        messageProcessorThread.start(); // Inicia el hilo procesador de mensajes

        // Apagar el ExecutorService de forma ordenada
        executor.shutdown(); // No acepta nuevas tareas, pero termina las que están en curso
        try {
            // Espera a que todos los hilos generadores terminen
            if (!executor.awaitTermination(60, TimeUnit.SECONDS)) {
                executor.shutdownNow(); // Si no terminan, los fuerza a cerrar
                System.err.println("Los hilos generadores no terminaron a tiempo, forzando cierre.");
            }
        } catch (InterruptedException e) {
            executor.shutdownNow();
            Thread.currentThread().interrupt();
            System.err.println("El hilo principal fue interrumpido mientras esperaba a los generadores.");
        }

        // Espera a que el hilo procesador de mensajes termine
        try {
            messageProcessorThread.join(); // Espera a que el hilo procesador termine su ejecución
        } catch (InterruptedException e) {
            System.err.println("El hilo principal fue interrumpido mientras esperaba al procesador de mensajes.");
            Thread.currentThread().interrupt();
        }

        System.out.println("\n--- Resumen Final ---");
        System.out.println("Total de números primos en la lista: " + primesList.getPrimesCount());
        System.out.println("Mensajes encriptados en la cola al finalizar: ");
        // Extraer y mostrar mensajes de la cola
        List<String> finalMessages = new ArrayList<>();
        while (!messageQueue.isEmpty()) {
            finalMessages.add(messageQueue.dequeueMessage());
        }
        System.out.println("Total de mensajes procesados: " + finalMessages.size());

        // Guardar los mensajes encriptados en un archivo
        guardarMensajesEncriptados(finalMessages, ENCRYPTED_MESSAGES_FILE);

        System.out.println("--- SafeVoteSystem Finalizado ---");
    }

    
    private static void cargarPrimesDesdeCSV(PrimesList primesList, String fileName) {
        System.out.println("\nCargando primos iniciales desde: " + fileName);
        System.out.println("Ruta absoluta para cargar primos: " + new File(fileName).getAbsolutePath());
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line = br.readLine(); // Asumimos una sola línea con todos los primos
            if (line != null && !line.trim().isEmpty()) {
                String[] primeStrings = line.split(",");
                List<Integer> loadedPrimes = new ArrayList<>();
                for (String s : primeStrings) {
                    try {
                        int prime = Integer.parseInt(s.trim());
                        if (primesList.isPrime(prime)) { 
                            loadedPrimes.add(prime);
                        } else {
                            System.err.println("Advertencia: '" + s.trim() + "' no es primo o es inválido en CSV. Saltando.");
                        }
                    } catch (NumberFormatException e) {
                        System.err.println("Error de formato numérico en CSV: '" + s.trim() + "'. " + e.getMessage());
                    }
                }
                primesList.addAll(loadedPrimes); 
                System.out.println("Carga de primos iniciales completada. Total cargados: " + loadedPrimes.size());
            } else {
                System.out.println("El archivo CSV de primos está vacío o no tiene contenido.");
            }
        } catch (FileNotFoundException e) {
            System.err.println("Error: Archivo de primos CSV no encontrado en " + fileName + ". Asegúrate de que existe.");
            System.err.println("Ruta buscada: " + new File(fileName).getAbsolutePath());
        } catch (IOException e) {
            System.err.println("Error de lectura del archivo de primos CSV: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.err.println("Error al añadir primos cargados: " + e.getMessage());
        }
    }

    
    private static void guardarMensajesEncriptados(List<String> messages, String fileName) {
        System.out.println("\nGuardando mensajes encriptados en: " + fileName);
        System.out.println("Ruta absoluta para guardar mensajes: " + new File(fileName).getAbsolutePath());
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (String message : messages) {
                writer.write(message);
                writer.newLine(); // Añade un salto de línea después de cada mensaje
            }
            System.out.println("Mensajes encriptados guardados exitosamente. Total: " + messages.size());
        } catch (IOException e) {
            System.err.println("Error al escribir mensajes encriptados en el archivo: " + e.getMessage());
            System.err.println("Ruta al intentar guardar mensajes: " + new File(fileName).getAbsolutePath());
        }
    }
}
