package com.mycompany.safesystem; 

import java.util.Random; 

public class PrimesThread implements Runnable {

    private final PrimesList primesList; // La lista compartida de números primos
    private final int numbersToGenerate; // Cantidad de números que este hilo intentará generar
    private final String threadName; // Nombre del hilo para identificación en la salida

    public PrimesThread(PrimesList primesList, int numbersToGenerate, String threadName) {
        this.primesList = primesList;
        this.numbersToGenerate = numbersToGenerate;
        this.threadName = threadName;
    }

    @Override
    public void run() {
        System.out.println(threadName + " ha iniciado la generación de números.");
        Random random = new Random(); // Generador de números aleatorios

        for (int i = 0; i < numbersToGenerate; i++) {
            // Genera un número aleatorio entre 2 y 1000
            int randomNumber = random.nextInt(999) + 2;

            try {
                // Verificamos si el número es primo antes de intentar añadirlo.
                // El método add de PrimesList ya está sincronizado y valida que sea primo.
                if (primesList.isPrime(randomNumber)) {
                    primesList.add(randomNumber); // Añade el número primo a la lista
                    System.out.println(threadName + ": Añadido primo " + randomNumber + ". Total: " + primesList.getPrimesCount());
                    primesList.notifyPrimesAvailable(); // Notifica que hay nuevos primos disponibles
                } else {
                    // System.out.println(threadName + ": " + randomNumber + " no es primo."); // Opcional: para ver no primos
                }
                
                Thread.sleep(random.nextInt(50)); // Pausa aleatoria hasta 50ms
            } catch (IllegalArgumentException e) {
                System.err.println(threadName + ": Error al añadir número: " + e.getMessage());
            } catch (InterruptedException e) {
                System.out.println(threadName + " ha sido interrumpido.");
                Thread.currentThread().interrupt(); // Restaura el estado de interrupción
                return; // Sale del método run
            }
        }
        System.out.println(threadName + " ha terminado de generar números.");
    }
}
