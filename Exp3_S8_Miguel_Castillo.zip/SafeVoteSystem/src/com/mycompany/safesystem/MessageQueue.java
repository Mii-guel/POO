package com.mycompany.safesystem; 

import java.util.concurrent.BlockingQueue; // Interfaz para colas que bloquean
import java.util.concurrent.LinkedBlockingQueue; // Implementación de BlockingQueue

public class MessageQueue {

    // Cola bloqueante para almacnar mensajes encriptado
    private final BlockingQueue<String> encryptedMessagesQueue;

    
    public MessageQueue() {
        
        this.encryptedMessagesQueue = new LinkedBlockingQueue<>();
    }

    
    public void enqueueMessage(String message) {
        try {
            encryptedMessagesQueue.put(message); 
            System.out.println("Mensaje encriptado añadido a la cola: " + message);
        } catch (InterruptedException e) {
            System.err.println("Error al añadir mensaje a la cola: " + e.getMessage());
            Thread.currentThread().interrupt();
        }
    }

    
    public String dequeueMessage() {
        try {
            String message = encryptedMessagesQueue.take(); // bloquea si la cola está vacía
            System.out.println("Mensaje encriptado recuperado de la cola: " + message);
            return message;
        } catch (InterruptedException e) {
            System.err.println("Error al recuperar mensaje de la cola: " + e.getMessage());
            Thread.currentThread().interrupt();
            return null;
        }
    }

    
    public void publishToTopic(String topicName, String message) {
        System.out.println("Publicando al Topic '" + topicName + "': " + message);
        enqueueMessage(message); 
                                 
    }

    
    public boolean isEmpty() {
        return encryptedMessagesQueue.isEmpty();
    }
}

